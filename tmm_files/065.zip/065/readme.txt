Midi Files for Theme Retrieval Results

_Annotator_0.mid        : annotated by human 0
_Annotator_1.mid        : annotated by human 1
_Annotator_2.mid        : annotated by human 2
_Cl.mid                 : annotated by Contrastive Learning
_Cl_wo_NoteDur.mid      : annotated by Contrastive Learning (w/o Note Duration Data Augmentation)
_Cl_wo_PthSft.mid       : annotated by Contrastive Learning (w/o Pitch Shift Data Augmentation)
_Cm.mid                 : annotated by Correlation Matrix
_Cosiatec.mid           : annotated by COSIATEC

All the files contain two track:
    Track 1 : Notes in non theme region
    Track 2 : Notes regarded as theme region by the coressponding method
    
We also use different instruments for the two tracks.
