Midi files for Eps Comparison

*_theme.mid		: the given theme condition

*_eps0.13.mid		: the generated midi file using eps=0.13 in DBSCAN

*_eps0.25.mid		: the generated midi file using eps=0.25 in DBSCAN