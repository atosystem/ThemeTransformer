Midi files for Temperature Comparison

*_theme.mid		: the given theme condition

*_temp1.2.mid		: the generated midi file using temperature=1.2 when sampling tokens in theme regions

*_temp1.8.mid		: the generated midi file using temperature=1.8 when sampling tokens in theme regions

In all midi files contain 3 tracks

	MELODY		: contains melody notes
	PIANO		: contains piano accompaniment
	Theme info track: annotate the theme regions (each note in this track represent a theme region with the time span same with the note)