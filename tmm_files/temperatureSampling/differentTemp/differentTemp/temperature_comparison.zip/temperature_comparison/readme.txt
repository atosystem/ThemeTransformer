Midi files for Temperature Comparison

*_theme.mid		: the given theme condition

*_temp1.2.mid		: the generated midi file using temperature=1.2 when sampling tokens in theme regions

*_temp1.8.mid		: the generated midi file using temperature=1.8 when sampling tokens in theme regions