Midi files for Eps Comparison

*_theme.mid		: the given theme condition

*_eps0.13.mid		: the generated midi file using eps=0.13 in DBSCAN

*_eps0.25.mid		: the generated midi file using eps=0.25 in DBSCAN

In all midi files contain 3 tracks

	MELODY		: contains melody notes
	PIANO		: contains piano accompaniment
	Theme info track: annotate the theme regions (each note in this track represent a theme region with the time span same with the note)